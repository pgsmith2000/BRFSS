#Write out analytic dataset

write.csv(BRFSS_i, file = "analytic.csv")